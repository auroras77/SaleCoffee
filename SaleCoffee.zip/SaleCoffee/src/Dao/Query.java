package Dao;



import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static util.FileUtil.*;

public class Query {
    public static void main(String[] args) {
        List<List<String>> list;
        List<List<String>> list2;
        list=ReadCSV();
        list2 = search(list);
        if(list2.size()>1) {
            SumMoney(list2);
        }
    }

    public static List search( List<List<String>> list) {
        String date="";
        System.out.println("请输入要查询的日期:(日期格式为XXXX-XX-XX)");
        Scanner sc = new Scanner(System.in);
        date = sc.next();
        List results = new ArrayList();
        Pattern pattern = Pattern.compile(date);

        for (int i = 0; i < list.size(); i++) {
            Matcher matcher = pattern.matcher(list.get(i).get(2));
            if (matcher.matches()) {
                results.add(list.get(i));
            }
        }
        if(results.size()<1) {
            System.out.println("没有当天的销售记录！");
        }
        else {
            for (int i = 0; i < results.size(); i++) {
                System.out.println(results.get(i));
            }
        }

        return results;
    }

    public static int SumMoney( List<List<String>> list){
        int sumMoney=0;
        int singleMoney=0;

        for (int i = 0; i < list.size(); i++) {
            singleMoney= Integer.parseInt(list.get(i).get(1));
            sumMoney+=singleMoney;

        }
        System.out.println("该日销售总金额为"+sumMoney+"元！");
        return sumMoney;
    }
}
