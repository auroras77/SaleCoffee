package util;

import entity.Beverage;
import java.io.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class FileUtil {
    public static final String SEPARATE_FIELD = ","; // 字段分隔 英文逗号
    public static final String SEPARATE_LINE = "\r\n"; //文件里面的换行符 行分隔

    public static void saveDrinkToFile(Beverage beverage) {
        //创建一个文件名
        String fileName = "D:/" +
                "销售记录" + ".csv";
        //判断本地是否存在这个文件
        //创建字节缓冲输入流去读取这个文件夹
        try {
            BufferedInputStream bis = new BufferedInputStream(new FileInputStream(fileName));
            if (bis != null) { //文件如果存在我们就修改文件
                //其实这个文件存在不存在可以使用File的exist方法来进行判断
                bis.close();  // 关闭输入流
                System.out.println("今日销售文件已经存在我们只用修改文件就可以了");
                creatFile(fileName, true, beverage);

            }
            //这里不会出现else 因为如果文件不存在就进入异常处理了
        } catch (FileNotFoundException e) {
            //文件不存在就进入异常处理  创建这个文件
            System.out.println("今天的销售文件不存在创建今天的文件");
            creatFile(fileName, false, beverage);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * 创建文件和修改文件的方法
     * 我们通过一个lebal标签来判断是创建一个文件，还是修改一个文件
     *
     * @param fileName 文件名
     * @param label    判断是创建文件还是修改文件 true为文件已经存在 只用修改  false为文件不存在创建文件
     * @param books
     */
    public static void creatFile(String fileName, boolean label, Beverage beverage) {
        LocalDateTime now = LocalDateTime.now();
        LocalDate localDate = now.toLocalDate();
        LocalTime localTime = now.toLocalTime();
        String formatTime = localTime.format(DateTimeFormatter.ofPattern("HH:mm:ss"));

        BufferedOutputStream bos = null;
        StringBuffer sbf = new StringBuffer();

        try {
            if (label) {
                bos = new BufferedOutputStream(new FileOutputStream(fileName, true));
            } else {
                bos = new BufferedOutputStream(new FileOutputStream(fileName));
                String[] fieldSort = {"饮品", "总价", "销售日期", "销售时间", "销售员工"};

                for (String fieldKey : fieldSort) {
                    sbf.append(fieldKey).append(SEPARATE_FIELD);
                }
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        List<String> employeeList=new ArrayList<>();
        employeeList.add("王铭");
        employeeList.add("张三");
        employeeList.add("李四");
        employeeList.add("赵六");
        Random random=new Random();

        sbf.append(SEPARATE_LINE);
        sbf.append(beverage.getName()).append(SEPARATE_FIELD);
        sbf.append(beverage.getSumprice()).append(SEPARATE_FIELD);
        sbf.append(localDate).append(SEPARATE_FIELD);
        sbf.append(formatTime).append(SEPARATE_FIELD);
        sbf.append(employeeList.get(random.nextInt(employeeList.size()))).append(SEPARATE_FIELD);

        String str = sbf.toString();
        byte bytes[] = new byte[0];
        try {
            bytes = str.getBytes("GBK");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        try {
            bos.write(bytes, 0, bytes.length);

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                bos.close();
                System.out.println("数据添加成功！");
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }

    public static List<List<String>> ReadCSV() {
        List<List<String>> dataList = new ArrayList<>();
        try {
            InputStream in = new FileInputStream("F:\\销售记录.csv");
            BufferedReader br = new BufferedReader(new InputStreamReader(in, "GBK"));
            String line = null;
            while ((line = br.readLine()) != null) {
                String aa[] = line.split(",");
                List<String> cellList = Arrays.asList(aa);
                dataList.add(cellList);
            }
            br.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return dataList;
    }

}
