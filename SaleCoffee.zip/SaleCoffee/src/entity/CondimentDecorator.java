package entity;
//配料
abstract class CondimentDecorator extends Beverage{
    Beverage beverage;
}


