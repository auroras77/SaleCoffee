package entity;

public class sugar extends CondimentDecorator {
    private final int SUGAR_PRICE = 1;
    public String getDescription(){
        return "糖"+beverage.getDescription();
    }
    public int cost(){
        return SUGAR_PRICE;
    }
    public sugar(Beverage beverage){
        this.beverage=beverage;
    }

}
