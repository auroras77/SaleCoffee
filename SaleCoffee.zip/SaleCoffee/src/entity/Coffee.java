package entity;

 public class Coffee extends CondimentDecorator {
     private final int COFFEE_PRICE=3;
     @Override
     public int cost() {
         return COFFEE_PRICE;

     }

     public Coffee(Beverage beverage){
         this.beverage=beverage;
     }
     public String getDescription(){
         return "咖啡"+beverage.getDescription();
     }

}
