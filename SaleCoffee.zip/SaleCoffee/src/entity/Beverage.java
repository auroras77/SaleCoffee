package entity;



public abstract class Beverage  {

    private String name;//名称
    private int num;//购买数量
    private int sumprice;//总价

    public int getSumprice() {
        return sumprice;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }

    public void setSumprice(int sumprice) {
        this.sumprice = sumprice;
    }

    public Beverage() {
    }

    public abstract  int cost();

    public String showBeverage(){
        return "订单信息：\n"+"您购买了："+name+"\n购买数量为："+num+"杯\n"+"总价为："+getSumprice();
    }

    String description="Unknow Beverage";

    public String getDescription() {
        return description;
    }

}
