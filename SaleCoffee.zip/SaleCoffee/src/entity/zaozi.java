package entity;

public class zaozi extends CondimentDecorator{
    private final int ZAOZI_PRICE = 2;
    @Override
    public int cost() {
        return ZAOZI_PRICE;
    }
    public zaozi(Beverage beverage){
        this.beverage=beverage;
    }
    public String getDescription(){
        return "枣子"+beverage.getDescription();
    }
}
