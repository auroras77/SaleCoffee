package entity;

//奶茶
public class MilkTea extends Beverage {
    public final int MILKTEA_PRICE=10;
    @Override
    public int cost() {
        return MILKTEA_PRICE;
    }

    public MilkTea() {
        description = "奶茶";
    }

}
