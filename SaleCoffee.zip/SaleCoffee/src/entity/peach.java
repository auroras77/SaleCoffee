package entity;

public class peach extends CondimentDecorator{
    private final int PEACH_PRICE = 2;
    @Override
    public int cost() {
        return PEACH_PRICE;
    }
    public peach(Beverage beverage){
        this.beverage=beverage;
    }
    public String getDescription(){
        return "桃汁"+beverage.getDescription();
    }
}
