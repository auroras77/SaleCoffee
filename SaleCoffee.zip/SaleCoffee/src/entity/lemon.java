package entity;

public class lemon extends CondimentDecorator {
    private final int LEMON_PRICE = 1;
    public lemon(Beverage beverage){
        this.beverage=beverage;
    }
    public String getDescription(){
        return "柠檬"+beverage.getDescription();
    }

    @Override
    public int cost() {
        return LEMON_PRICE;
    }
}
