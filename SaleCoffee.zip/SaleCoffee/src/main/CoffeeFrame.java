package main;

import entity.*;
import util.FileUtil;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


public class CoffeeFrame {
    static Scanner sc = new Scanner(System.in);
    public static void main(String[] args) {
        showMenu();
        System.out.println("请输入购买数量：");
        int num=sc.nextInt();
        Beverage beverage =new MilkTea();
        beverage.setNum(num);
        ArrayList<Integer> datas=new ArrayList<>();
        int flag=0;
        while (true) {
            String isAdd = "";
            int option = 0;
            if(flag==0) {
                sc = new Scanner(System.in);
                System.out.println("请问是否需要添加配料？是：y 否：n");
                isAdd = sc.next();
                if ("y".equals(isAdd)) {
                    AddCondiment(datas);
                    flag=1;
                }
                else if ("n".equals(isAdd)) {
                    if (datas.size() > 0) {
                        beverage = isSelected(beverage, datas);
                        beverage.setNum(num);
                         break;
                    } else {
                        beverage.setNum(num);
                        beverage.setName(beverage.getDescription());
                        beverage.setSumprice(beverage.getNum() * beverage.cost());
                          break;
                    }
                }
                else break;
            }
            else {
                System.out.println("请问是否需要继续添加配料？是：y 否：n");
                isAdd = sc.next();
                if ("y".equals(isAdd)) {
                    AddCondiment(datas);
                    flag=1;
                }
                else if ("n".equals(isAdd)) {
                    if (datas.size() > 0) {
                        beverage = isSelected(beverage, datas);
                        beverage.setNum(num);
                         break;
                    } else {
                        beverage.setNum(num);
                        beverage.setName(beverage.getDescription());
                        beverage.setSumprice(beverage.getNum() * beverage.cost());
                          break;
                    }
                }
                else break;
            }
        }
        System.out.println(beverage.showBeverage());
        FileUtil.saveDrinkToFile(beverage);
        System.out.println("欢迎下次光临！");

    }

   public static void showMenu(){
        System.out.println("*************菜单**************");
        System.out.println("**********奶茶---10￥**********");
        System.out.println("*************配料*************");
        System.out.println("***********糖---1￥************");
        System.out.println("***********咖啡---3￥**********");
        System.out.println("***********桃汁---2￥**********");
        System.out.println("***********柠檬---1￥**********");
        System.out.println("***********枣子---2￥**********");
    }

    public static List<Integer> AddCondiment(ArrayList<Integer> datas){
        int option=0;
            System.out.println("请输入您需要添加的配料：");
            System.out.println("***********1、糖---1￥************");
            System.out.println("***********2、咖啡---3￥**********");
            System.out.println("***********3、桃汁---2￥**********");
            System.out.println("***********4、柠檬---1￥**********");
            System.out.println("***********5、枣子---2￥**********");
            option = sc.nextInt();
            datas.add(option);
        return datas;
    }

    public static Beverage isSelected(Beverage beverage,ArrayList<Integer> datas){

        int cost=beverage.cost()*beverage.getNum();
        for(Integer data : datas){
            if(data==1){
                beverage=new sugar(beverage);
                beverage.getDescription();
            }
            if(data==2){
                beverage=new Coffee(beverage);
                beverage.getDescription();
            }
            if(data==3){
                beverage=new peach(beverage);
                beverage.getDescription();
            }
            if(data==4){
                beverage=new lemon(beverage);
                beverage.getDescription();
            }
            if(data==5){
                beverage=new zaozi(beverage);
                beverage.getDescription();
            }
            cost = cost+beverage.cost();
            beverage.setName(beverage.getDescription());
        }
        beverage.setSumprice(cost);
        return beverage;
    }

}




